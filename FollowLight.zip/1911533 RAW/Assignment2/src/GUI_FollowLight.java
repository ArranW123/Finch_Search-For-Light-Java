import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;

import edu.cmu.ri.createlab.terk.robot.finch.Finch;


public class GUI_FollowLight {
	
	private JFrame MenuFrame; //frame
	private JPanel MenuPanel; //panel
	private JButton StartButton; //button
	private JButton HelpButton; //button
	private JLabel TitleLabel; //label
	
// ------------------------------------------------- MainMainGui -------------------------------------------------------------
	public void MainMenuGui() //Method
	{
		//JFrame - MenuFrame
		MenuFrame = new JFrame("Search for Light"); //Title of the frame
		MenuFrame.setVisible(true); //To set the frame to be visible to the user
		MenuFrame.setLocationRelativeTo(null); //Makes the frame open on center point
		MenuFrame.setSize(600,400); //Determines the resolution of the frame
		MenuFrame.setResizable(false); //Removes the ability to resize the frame
		MenuFrame.setBackground(Color.WHITE);//Colour background
		MenuFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);//Removes the default closing operation (to add a exit prompt)
		MenuFrame.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) //This is the exit prompt, once the user clicks the "X" button, then it should deliver a message box asking if the user wants to quit.
			{
				int x = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Search for Light", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
				
				if (x == JOptionPane.YES_OPTION) //If the user selects "Yes" button...
				{
					e.getWindow().dispose();
					System.out.println("Thank you for using the program!");
					System.exit(0);

				} //else, the prompt just closes..
				
			}
		});
		
		//JPanel - MenuPanel
		MenuPanel = new JPanel(new GridBagLayout()); //GridBagLayout = is used to help layout the components (Buttons and labels) correctly
		MenuPanel.setBackground(Color.WHITE); //Colour background = white
		
		//JButton - StartButton
		StartButton = new JButton("Start"); 
				
		StartButton.addActionListener(new ActionListener() //Start Button Action 
		{
			public void actionPerformed(ActionEvent e) //This button executes the program...
			{
				
				FollowLight FollowLightProgram = new FollowLight();
				MenuFrame.dispose();
				
				
				FollowLightProgram.checkFinchLevel(); //...it starts with the program checking if the Finch is levelled correctly...
				FollowLightProgram.FinchStart(); //...if it is levelled, then the program run...
				FollowLightProgram.FinchExit(); //...After that call then it will produce another JFrame which is the LogExecutionGUI
				
					
			}
			
			
		});
		
		//JButton - HelpButton
		HelpButton = new JButton("Help");
		HelpButton.addActionListener(new ActionListener()
		{

			
			public void actionPerformed(ActionEvent e) //Once the user clicks the button, a message box appears guiding the user how to use the program
			{
				JOptionPane.showMessageDialog(MenuFrame, "1) Make sure that the Finch is connected to Desktop PC/Laptop\n" + " \n" + "2) Make sure that the room is dark for the optimal experience \n" + " \n"+ "3) Want to stop the program? Just place the Finch on its bottom and it will quit or press the 'X' button on the top right \n" + " \n" + "Enjoy the program!", null, JOptionPane.QUESTION_MESSAGE );
				
			}
			
		});

		GridBagConstraints Layout = new GridBagConstraints();

		
		//JLabel
		TitleLabel = new JLabel("Search Light");
		TitleLabel.setFont(new Font("Arial", Font.BOLD,50));
		
		//Positioning of components in GUI
		Layout.insets = new Insets(40,40,40,40); //Creates spacing between other components
		Layout.gridx = 0;
		Layout.gridy = 2;
		MenuPanel.add(StartButton, Layout); //Adds StartButton to Panel
		
		Layout.gridx = 0;
		Layout.gridy = 1;
		
		MenuPanel.add(TitleLabel, Layout); //Adds TitleLabel to Panel
		
		Layout.gridx = 0;
		Layout.gridy = 3;
		MenuPanel.add(HelpButton, Layout); //Adds HelpButton to Panel

		MenuFrame.add(MenuPanel);
		
		
	}

// ---------------------------------- Log Execution Frame ----------------------------------------------------------------------------
	public void LogExecutionGUI()
	{
		JFrame LogExecutionFrame = new JFrame();
		LogExecutionFrame.setVisible(true); // This sets the frame to become visible to the user
		LogExecutionFrame.setLocationRelativeTo(null); // This allows the frame it display in the middle, rather than the top left.
		LogExecutionFrame.setSize(600,400);
		LogExecutionFrame.setResizable(false); //This disable the functionality of resizing the frame 
		
		LogExecutionFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		LogExecutionFrame.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) //This part of the code displays a exit prompt, asking if the user wants to quit the program
			{
				int x = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Search for Light", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
				
				if (x == JOptionPane.YES_OPTION) //If the user selects "YES" then the program will dispose the frame and display a thank you message.
				{
					e.getWindow().dispose();
					System.out.println("Thank you for using the program!");
					System.exit(0);
				} //else, it closes the prompt
				
			}
		});
					
		JPanel LogExecutionPanel = new JPanel(new GridBagLayout());
		
		JLabel DisplayLogLabel = new JLabel("Do you want to display log?");
		DisplayLogLabel.setFont(new Font("Arial", Font.BOLD,15)); 
		
		//JButton
		JButton YesButton = new JButton("Yes");
		JButton NoButton = new JButton("No");
		
		YesButton.addActionListener(new ActionListener()
		{
			
			public void actionPerformed(ActionEvent e) 
			{
				FollowLight FollowLightProgram = new FollowLight();
				LogExecutionFrame.dispose();
				
				try //What this try and catch does is if LogExecution is executable, then run it if not, Run this System.out.println().. explaining that there is an error..
				{
					FollowLightProgram.LogExecution();	
				} catch(Exception f)
				
				{
					System.out.println("Error: Log Execution cannot be calculated, Have the Finch placed down before pressing the 'start' button ");
					System.out.println("--------------------------------------------------------");
				}
				
				

			}
			
		});
		
		NoButton.addActionListener(new ActionListener() { //If the user selects No, then it will quit the program all together
			
			public void actionPerformed(ActionEvent e)
		
			{
				System.out.println("Thank you for using the program!");
				System.exit(0);
			}
			
		});
		
		//Positioning of Components
		GridBagConstraints LELayout = new GridBagConstraints();

		LELayout.insets = new Insets(80,20,20,20);
		LELayout.gridx = 0;
		LELayout.gridy = 5;
		LogExecutionPanel.add(YesButton, LELayout); //Adds YesButton
		
		LELayout.gridx = 2;
		LELayout.gridy = 5;
		LogExecutionPanel.add(NoButton, LELayout);//Adds NoButton
	
		LELayout.insets = new Insets(0,0,0,0);
		LELayout.gridx = 1;
		LELayout.gridy = 1;

		LogExecutionPanel.add(DisplayLogLabel, LELayout);//Adds DisplayLogLabel 
		LogExecutionFrame.add(LogExecutionPanel);//Adds Panel to Frame
		
		
	}
	
	
}
