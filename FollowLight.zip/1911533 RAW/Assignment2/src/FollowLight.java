import java.util.ArrayList;
import java.util.Date;
import edu.cmu.ri.createlab.terk.robot.finch.Finch;
import java.awt.Desktop;
import java.io.*;


public class FollowLight {

	//Global Variables	
	public static Finch MyFinch;
	static int LightCounter = 0;
	static ArrayList<Integer>LightArray = new ArrayList <Integer>();
	static long startTimer;
	static long finchStartTime; //This calculates the Time Execution (How long the program has been running)


	//Beginning Light Sensor Arrays - Used for Beginning values
	static ArrayList<Integer>LeftStart = new ArrayList <Integer>(); //Collects the left light
	static ArrayList<Integer>RightStart = new ArrayList <Integer>(); //Collects the right light

	public static void main(String[] args) {

		MyFinch = new Finch(); //Initiates Finch 

		GUI_FollowLight GUI1 = new GUI_FollowLight();
		GUI1.MainMenuGui(); //This calls the first GUI frame (MainMenu)
		
		}
	

	//Following are the member variables for running the Finch
	long TimeExecution = 0;
	int min = 99999;
	int max = 0;
	int average = 0;
	
	
	public void checkFinchLevel()
	{
		if( MyFinch.isBeakUp()== true) //This is ran at the start of the program checking if the Finch is levelled correctly (isbeakup())
			System.out.println("Place Finch on the Floor");
		return;
			
	}
		
	
	public void FinchStart() //After checking checkfichLevel(), it will run this method. This is the start of the movement where it checks if the Finch cannot detect light or if the Finch has detected Light
	{
		
		int startLight = MyFinch.getLeftLightSensor(); //It retrieves a light sensor value
		int leftstartlight = MyFinch.getLeftLightSensor(); //This variable is used to retrieve the starting left light sensor
		int rightstartlight = MyFinch.getRightLightSensor(); //This variable is used to retrieve the starting right light sensor
		int light = 0; //This is a threshold variable where if the light sensor values are over the set
		finchStartTime = System.currentTimeMillis(); //Calculates the time execution
	
	//----Finch program started ----
		
		
	boolean timerStarted = false; //This is a idle trigger

		
	while (MyFinch.isBeakUp() == false) //While the beak is down, it runs the program. If its up then it will run FinchExit(), which produces;
	{
		
		LeftStart.add(leftstartlight);	
		RightStart.add(rightstartlight);
		
		light = MyFinch.getLeftLightSensor() + MyFinch.getRightLightSensor();

		if (light >= 7) // if the light is more than 7 or equal to 7, executes LightMovement method
		{
						
			LightMovement(startLight); //Code for the Finch to follow the light
			timerStarted = false;
			
		}
		
		else
		{
		
			if (timerStarted == false) //else if the timerStarted is false, declares the startTimer and timerStarted is true (this means that the 4 second idle will initate)
		        {
				startTimer = System.currentTimeMillis();
				MyFinch.setLED(200,200,0);
				MyFinch.setWheelVelocities(100, 100);
				timerStarted = true;
		        }
		
					
			if (System.currentTimeMillis() - startTimer > 4000) //if light hasn't been detected for more than 4 seconds, it will stop, turn 90 degrees and reset the timer and switches the timerStarted back to false
			{
				MyFinch.setLED(0,0,255); //Beak turns blue
				MyFinch.setWheelVelocities(0,0,500); //Stop 1/2 second
				MyFinch.setWheelVelocities(-100, 100, 1000); //90 Degrees
				startTimer =System.currentTimeMillis();
				timerStarted = false;
			}
		
		}	
	}		
			
			
	}

	public void LightMovement(int startLight) { //Method for Movement
		MyFinch.setLED(200,200,0);
		MyFinch.setWheelVelocities(100,100);


		//Declaring Variables
		int LeftLight = MyFinch.getLeftLightSensor(); //getLeftLightSensor() is stored in LeftLight variable to be used in conditions
		int RightLight = MyFinch.getRightLightSensor(); //getRightLightSensor() is stored in RightLight variable to be used in conditions
		int LightMovementLED = (LeftLight + RightLight); // Make a variable for the red colour, if there is more light the variable value increases and increases the colour RED

				
		if (LightMovementLED > 255) //This condition is placed to reduce any errors in the LED
		{
			LightMovementLED =  255; //This variable would increase in value depending on the light density. But 	
		}

		//		MyFinch.setLED(LightMovementLED,0,0); // This variable would increase in value depending on the light density.			

		if (LeftLight > RightLight + 25) {
			
			MyFinch.setLED(LightMovementLED, 0,0);
			LeftMovement(LeftLight, RightLight, LightMovementLED); //this would start the movement conditions
		} 
		
		else if (RightLight > LeftLight + 25 )
		{
			MyFinch.setLED(LightMovementLED, 0,0);
			RightMovement(LeftLight, RightLight, LightMovementLED);

		}
	}
		

	public static void LeftMovement(int LL, int RL, int LML) //LL = LeftLight, RL = RightLight, LML = LightMovementLED

	{ 
		MyFinch.setWheelVelocities(RL, LL,250); //Finch moves left according to the light values
		MyFinch.buzz(5000, 1000); //Finch buzzes as the finch encounters light


		if (LML > 50) //if both of the light sensors goes over 50, then it increments the counter
		{
			LightCounter++;
			System.out.println("Light Detected: " + LightCounter + " Times");
			System.out.println("Left Light Sensor: " + LL + " Right Light Sensor: " + RL);

		}

		LightArray.add(LML);

	}
	

	public static void RightMovement(int LL, int RL, int LML)
	{

		MyFinch.setWheelVelocities(RL, LL,250); //Finch moves right according the light values
		MyFinch.buzz(5000, 1000); //The Finch buzzes as the Finch encounters light

		if (LML > 50) // If both of the light sensors goes over 50, then the counter increments
		{
			LightCounter++; 
			System.out.println("Light Detected: " + LightCounter + " Times");
			System.out.println("Left Light Sensor: " + LL + " Right Light Sensor: " + RL);

		}

		LightArray.add(LML); //The both Left and Right light values are stored in the LightArray list.


	}
	

	public void getMin() //This calculates the Minimum for the LightArray

	{

		for (int i = 0; i < LightArray.size(); i++) //this checks if i is less than the LightArray, if it is then it increments "i"
		{
			if (LightArray.get(i) <= min) //This checks if the value that is stored (i) is less than or equal to min
			{
				min = LightArray.get(i); //Then "i" is stored in min
			} 
		}
		
	if (min == 99999) //this checks if the program is using the default value "99999" that is stored in "min" at the start of the program
	{
		min = 0; //Min is set to 0
		System.out.println("Light Sensor Minimum Value: " + min);
	}
	else
	{
		System.out.println("Light Sensor Minimum Value: " + min);
	}
	
	}
	

	public void getMax() 
	{

		for (int i = 0; i < LightArray.size(); i++)  //This checks if "i" > LightArray list size and then increments "i" 
		{
			if (LightArray.get(i) >= max) //if i is more than or equal to max 
			{
				max = LightArray.get(i); //then max equals "i"
			}
		}
		System.out.println("Light Sensor Maximum Value: " + max);
	}
	
	
	public void getAverage() //This calculates the average of both light sensors
	{
		int total = 0;
		
	
			for (int j = 0; j<LightArray.size(); j++) //if "j" is less than the LightArray size, then it increments "j"
			{
				total = total + LightArray.get(j); //Then it LightArray.get(j) is stored
			}
			
		average = total/LightArray.size(); //This divides the total by how many array elements there are in the LightArray list
		System.out.println("Average Light Values: " + average); 
	
	}
	

	public void LogExecution() //This is the console Log Execution
	{

		
		System.out.println("Program stops");
		System.out.println(" ");
		System.out.println("--------------------------------------------------------");
		System.out.println("Beginning Left Light Sensor Values: " + LeftStart.get(0)); //Beginning Light values //startLight
		System.out.println("Beginning Right Light Sensor Values: " + RightStart.get(0)); //Beginning Light values //startLight
		getMax(); //Maximum Value
		getMin(); //Minimum Value
		System.out.println("Light Detected: " + LightCounter + " Times"); //Light Detected
		
		TimeExecution = System.currentTimeMillis() - finchStartTime;
		System.out.println("Time of Execution: " + (TimeExecution/1000) + " Seconds"); //Time Elapsed
		
		try //This try catch statement, prevents logical error when the calculation is run, this can be due to no values in the LightArray and producing average with no values
		{
			getAverage(); //Average
		
		} catch(ArithmeticException e)
		
		{
			System.out.println("Average Light Values: This calculation cannot be processed");
			average = 0;
		}
		
		System.out.println("--------------------------------------------------------");
	
		try // this try catch is the same above, this prevents any logic errors and File not found errors.
		{
			LogExecutionFileHandling(TimeExecution);
		} catch (FileNotFoundException e)
		
		{
			e.printStackTrace();
		}
	
		
	}
	
	
	public void FinchExit() //After the Finch has its beak up during execution, LogExecutionGUI will pop up
	{
		MyFinch.setWheelVelocities(0,0); //This is to prevent the Finch from moving 
		GUI_FollowLight NextWindow= new GUI_FollowLight();
		NextWindow.LogExecutionGUI();

	}
	
	
	public void LogExecutionFileHandling(long TimeExecution) throws FileNotFoundException
	{
		File file = new File("LogExecution.txt");
		
			PrintWriter output = new PrintWriter(file);
			Date date = java.util.Calendar.getInstance().getTime(); //This displays the date and time in the text file
			output.println("Search for Light");
			output.println(" ");
			output.println(date); //This displays the date and time in the text file
			output.println(" ");
			output.println("----------------------------------------------");
			output.println(" ");
			output.println("Beginning Left Light Sensor Values: " + LeftStart.get(0)); //Beginning Left Light Sensors
			output.println(" ");
			output.println("Beginning Right Light Sensor Values: " + RightStart.get(0)); //Beginning Right Light Sensors
			output.println(" ");
			output.println("Light Sensor Maximum Value: "+ max); //Maximum values
			output.println(" ");
			output.println("Light Sensor Minimum Value: "+ min); //Minimum Values
			output.println(" ");
			output.println("Light Detected: " + LightCounter + " Times"); //Number of times light is detected
			output.println(" ");
			output.println("Time of Execution: " + (TimeExecution/1000) + " Seconds"); //Time of execution
			output.println(" ");
			output.println("Average Light Values: " + average); //Average values
			output.println(" ");
			output.println("----------------------------------------------");
			output.println(" ");
			output.println("Developed by: Arran Weeresekere (1911533)");
			
			output.close();
			
			//This opens the file through desktop 
			Desktop desktop = Desktop.getDesktop();
			
			try //this try and catch will prevent a IOException where the reason could be that the text file can't be opened or the file cannot be saved. 
			{
				desktop.open(file);
			} catch (IOException e) 
			{
				System.out.println("ERROR: File cannot be opened or saved");
				e.printStackTrace();
			}
			
			MyFinch.quit();
			System.exit(0);	
		
			
	}

}

